// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
  // Date display
  updateDateDisplay();
  
  // Set theme and subject based on URL parameters if on notebook page
  if (window.location.pathname.includes('notebook.html')) {
    setupNotebookPage();
  }
  
  // Add event listeners to theme buttons for sound effects
  setupSoundEffects();
  
  // Setup modal dialogs
  setupModals();
});

// Update date display
function updateDateDisplay() {
  const dateDisplay = document.getElementById('dateDisplay');
  if (!dateDisplay) return;
  
  const today = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  dateDisplay.textContent = today.toLocaleDateString('en-US', options);
}

// Set up the notebook page with theme and subject from URL
function setupNotebookPage() {
  const params = new URLSearchParams(window.location.search);
  const themeCode = params.get('theme');
  const subjectCode = params.get('subject');
  
  if (!themeCode || !subjectCode) {
    window.location.href = 'index.html';
    return;
  }
  
  // Add theme class to body
  document.body.classList.add(`theme-${themeCode}`);
  
  // Set the back button href
  const backButton = document.getElementById('back-to-subjects');
  if (backButton) {
    backButton.href = `theme-${themeCode}.html`;
  }
  
  // Set the notebook title
  const notebookTitle = document.getElementById('notebook-title');
  if (notebookTitle) {
    // Capitalize first letter of subject
    const subjectName = subjectCode.charAt(0).toUpperCase() + subjectCode.slice(1);
    
    // Get theme name
    let themeName = '';
    switch(themeCode) {
      case 'hp': themeName = 'Harry Potter'; break;
      case 'io': themeName = 'Inside Out'; break;
      case 'sg': themeName = 'Studio Ghibli'; break;
      case 'hl': themeName = 'Homelander'; break;
    }
    
    notebookTitle.textContent = `${themeName} - ${subjectName} Notebook`;
  }
  
  // Set up folder click events
  setupFolderEvents();
  
  // Set up note interactions
  setupNoteEvents();
  
  // Set up pagination
  setupPagination();
}

// Setup folder selection
function setupFolderEvents() {
  const folders = document.querySelectorAll('.folder');
  
  folders.forEach(folder => {
    folder.addEventListener('click', function() {
      // Remove active class from all folders
      folders.forEach(f => f.classList.remove('active'));
      
      // Add active class to clicked folder
      this.classList.add('active');
      
      // Update current folder name display
      const folderName = this.querySelector('.folder-name').textContent;
      const currentFolderNameElement = document.getElementById('current-folder-name');
      if (currentFolderNameElement) {
        currentFolderNameElement.textContent = folderName;
      }
      
      // Play sound effect
      playBubbleClickSound();
      
      // In a real app, we would load notes for this folder here
      // For demo purposes, we'll just keep the existing notes
    });
  });
}

// Setup note interactions
function setupNoteEvents() {
  const checkboxes = document.querySelectorAll('.note-complete-checkbox');
  
  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', function() {
      const noteCard = this.closest('.note-card');
      
      if (this.checked) {
        // Play completion sound
        playCompletionSound();
        
        // Visually mark as completed
        noteCard.style.opacity = '0.7';
        noteCard.style.textDecoration = 'line-through';
      } else {
        // Reset styles
        noteCard.style.opacity = '1';
        noteCard.style.textDecoration = 'none';
      }
      
      // In a real app, we would update the server here
      updateProgressIndicators();
    });
    
    // Initialize the visual state based on checkbox
    const noteCard = checkbox.closest('.note-card');
    if (checkbox.checked) {
      noteCard.style.opacity = '0.7';
      noteCard.style.textDecoration = 'line-through';
    }
  });
}

// Setup pagination
function setupPagination() {
  const prevButton = document.getElementById('prev-page');
  const nextButton = document.getElementById('next-page');
  const currentPageElement = document.getElementById('current-page');
  const totalPagesElement = document.getElementById('total-pages');
  
  if (!prevButton || !nextButton || !currentPageElement || !totalPagesElement) return;
  
  let currentPage = 1;
  const totalPages = 3; // Demo value
  
  currentPageElement.textContent = currentPage;
  totalPagesElement.textContent = totalPages;
  
  prevButton.addEventListener('click', function() {
    if (currentPage > 1) {
      currentPage--;
      currentPageElement.textContent = currentPage;
      
      // Enable/disable buttons
      prevButton.disabled = currentPage === 1;
      nextButton.disabled = false;
      
      // Play sound
      playBubbleClickSound();
      
      // In a real app, we would load notes for this page
    }
  });
  
  nextButton.addEventListener('click', function() {
    if (currentPage < totalPages) {
      currentPage++;
      currentPageElement.textContent = currentPage;
      
      // Enable/disable buttons
      prevButton.disabled = false;
      nextButton.disabled = currentPage === totalPages;
      
      // Play sound
      playBubbleClickSound();
      
      // In a real app, we would load notes for this page
    }
  });
}

// Setup modal dialogs
function setupModals() {
  // New folder modal
  const newFolderBtn = document.getElementById('new-folder-btn');
  const newFolderModal = document.getElementById('new-folder-modal');
  const cancelFolderBtn = document.getElementById('cancel-folder');
  const newFolderForm = document.getElementById('new-folder-form');
  
  if (newFolderBtn && newFolderModal && cancelFolderBtn && newFolderForm) {
    newFolderBtn.addEventListener('click', function() {
      newFolderModal.classList.add('show');
    });
    
    cancelFolderBtn.addEventListener('click', function() {
      newFolderModal.classList.remove('show');
    });
    
    newFolderForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const folderNameInput = document.getElementById('folder-name');
      if (folderNameInput && folderNameInput.value.trim()) {
        // In a real app, we would save the folder here
        addFolder(folderNameInput.value.trim());
        newFolderModal.classList.remove('show');
        folderNameInput.value = '';
      }
    });
  }
  
  // New note modal
  const newNoteBtn = document.getElementById('new-note-btn');
  const newNoteModal = document.getElementById('new-note-modal');
  const cancelNoteBtn = document.getElementById('cancel-note');
  const newNoteForm = document.getElementById('new-note-form');
  
  if (newNoteBtn && newNoteModal && cancelNoteBtn && newNoteForm) {
    newNoteBtn.addEventListener('click', function() {
      newNoteModal.classList.add('show');
    });
    
    cancelNoteBtn.addEventListener('click', function() {
      newNoteModal.classList.remove('show');
    });
    
    newNoteForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const noteContentInput = document.getElementById('note-content');
      if (noteContentInput && noteContentInput.value.trim()) {
        // In a real app, we would save the note here
        addNote(noteContentInput.value.trim());
        newNoteModal.classList.remove('show');
        noteContentInput.value = '';
      }
    });
  }
}

// Add a new folder to the UI
function addFolder(folderName) {
  const foldersList = document.getElementById('folders-list');
  if (!foldersList) return;
  
  const newId = Date.now(); // Simple ID generation
  
  const newFolder = document.createElement('li');
  newFolder.className = 'folder';
  newFolder.dataset.folderId = newId;
  newFolder.innerHTML = `<span class="folder-name">${folderName}</span>`;
  
  foldersList.appendChild(newFolder);
  
  // Add click event
  newFolder.addEventListener('click', function() {
    const folders = document.querySelectorAll('.folder');
    folders.forEach(f => f.classList.remove('active'));
    this.classList.add('active');
    
    const currentFolderNameElement = document.getElementById('current-folder-name');
    if (currentFolderNameElement) {
      currentFolderNameElement.textContent = folderName;
    }
    
    playBubbleClickSound();
  });
}

// Add a new note to the UI
function addNote(noteContent) {
  const notesContainer = document.getElementById('notes-container');
  if (!notesContainer) return;
  
  const newId = Date.now(); // Simple ID generation
  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  const newNote = document.createElement('div');
  newNote.className = 'note-card';
  newNote.dataset.noteId = newId;
  newNote.innerHTML = `
    <div class="note-header">
      <input type="checkbox" class="note-complete-checkbox">
      <span class="note-date">${formattedDate}</span>
    </div>
    <div class="note-content">
      <p>${noteContent}</p>
    </div>
  `;
  
  // Insert at the beginning
  notesContainer.insertBefore(newNote, notesContainer.firstChild);
  
  // Add checkbox event
  const checkbox = newNote.querySelector('.note-complete-checkbox');
  checkbox.addEventListener('change', function() {
    if (this.checked) {
      playCompletionSound();
      newNote.style.opacity = '0.7';
      newNote.style.textDecoration = 'line-through';
    } else {
      newNote.style.opacity = '1';
      newNote.style.textDecoration = 'none';
    }
    
    updateProgressIndicators();
  });
}

// Update progress indicators
function updateProgressIndicators() {
  // In a real app, this would calculate actual progress
  // For demo purposes, we'll just count completed checkboxes
  
  const checkboxes = document.querySelectorAll('.note-complete-checkbox');
  const completedCheckboxes = document.querySelectorAll('.note-complete-checkbox:checked');
  
  if (checkboxes.length === 0) return;
  
  const progressPercentage = Math.round((completedCheckboxes.length / checkboxes.length) * 100);
  
  // Update all battery progress indicators
  const batteryLevels = document.querySelectorAll('.battery-level');
  const batteryPercentages = document.querySelectorAll('.battery-percentage');
  
  batteryLevels.forEach(level => {
    level.style.width = `${progressPercentage}%`;
  });
  
  batteryPercentages.forEach(percentage => {
    percentage.textContent = `${progressPercentage}%`;
  });
}

// Sound effects
function setupSoundEffects() {
  const themeButtons = document.querySelectorAll('.theme-button');
  const subjectButtons = document.querySelectorAll('.subject-button');
  
  themeButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      playBubbleClickSound();
      const themeCode = this.dataset.theme;
      if (themeCode) {
        playThemeSound(themeCode);
      }
    });
  });
  
  subjectButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      playBubbleClickSound();
    });
  });
}

// Sound effect functions
function playBubbleClickSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator for the bubble sound
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - bubble pop sound
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioContext.currentTime); // Start at A5
    oscillator.frequency.exponentialRampToValueAtTime(220, audioContext.currentTime + 0.2); // Down to A3
    
    // Configure gain (volume) for the bubble pop effect
    gainNode.gain.setValueAtTime(0.05, audioContext.currentTime); // Start quiet
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.02); // Quick rise
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3); // Long decay
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (error) {
    console.error("Failed to generate bubble click sound:", error);
  }
}

function playCompletionSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - completion sound
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4
    oscillator.frequency.setValueAtTime(554.37, audioContext.currentTime + 0.1); // C#5
    oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.2); // E5
    
    // Configure gain (volume)
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + 0.1);
    gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.2);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.5);
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.error("Failed to generate completion sound:", error);
  }
}

function playThemeSound(themeCode) {
  switch (themeCode) {
    case 'hp':
      playHpSound();
      break;
    case 'io':
      playIoSound();
      break;
    case 'sg':
      playSgSound();
      break;
    case 'hl':
      playHlSound();
      break;
  }
}

function playHpSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - magical sound
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4
    oscillator.frequency.exponentialRampToValueAtTime(880, audioContext.currentTime + 0.1); // A5
    oscillator.frequency.exponentialRampToValueAtTime(587.33, audioContext.currentTime + 0.2); // D5
    
    // Configure gain (volume)
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3);
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (error) {
    console.error("Failed to generate HP sound:", error);
  }
}

function playIoSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - emotion sound
    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
    oscillator.frequency.linearRampToValueAtTime(783.99, audioContext.currentTime + 0.15); // G5
    
    // Configure gain (volume)
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + 0.15);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3);
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (error) {
    console.error("Failed to generate IO sound:", error);
  }
}

function playSgSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - gentle nature sound
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(392, audioContext.currentTime); // G4
    oscillator.frequency.linearRampToValueAtTime(523.25, audioContext.currentTime + 0.1); // C5
    oscillator.frequency.linearRampToValueAtTime(659.25, audioContext.currentTime + 0.2); // E5
    
    // Configure gain (volume)
    gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.4);
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.4);
  } catch (error) {
    console.error("Failed to generate SG sound:", error);
  }
}

function playHlSound() {
  try {
    // Create audio context
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Create oscillator
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure oscillator - strong heroic sound
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4
    oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.15); // E5
    
    // Configure gain (volume)
    gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.2, audioContext.currentTime + 0.15);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
    
    // Start and stop the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.4);
  } catch (error) {
    console.error("Failed to generate HL sound:", error);
  }
}